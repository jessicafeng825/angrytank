﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBulletController : MonoBehaviour
{
    public GameObject playerObject = null;
    public float bulletSpeed = 15.0f;               //表示子弹的速度
    private float selfDestructTimer = 0.0f;         //表示子弹自我销毁的时间
    void Update()
    {
        //在一段时间以后销毁子弹对象
        if (selfDestructTimer > 0.0f)
        {
            if (selfDestructTimer < Time.time)
                Destroy(gameObject);
        }
    }
    //调用此函数发射子弹
    public void launchBullet()
    {
        //确定精灵对象的朝向
        float mainXScale = playerObject.transform.localScale.x;
        Vector2 bulletForce;                        //对子弹施加的力的方向
                                                    //如果精灵对象面朝左，则向左发射子弹
        if (mainXScale < 0.0f)
        {
            bulletForce = new Vector2(bulletSpeed * -1.0f, 0.0f);
        }
        //如果精灵对象面朝右，则向右发射子弹
        else
        {
            bulletForce = new Vector2(bulletSpeed, 0.0f);
        }
        //施加给子弹对象一个指定方向的力
        GetComponent<Rigidbody2D>().velocity = bulletForce;
        //在1秒后销毁子弹对象
        selfDestructTimer = Time.time + 1.0f;
    }

}
