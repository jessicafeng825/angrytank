﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathTriggerScript : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D collidedObject)
    {
        //调用精灵对象上PlayerStateListener组件里的hitDeathTrigger()函数
        collidedObject.SendMessage("hitDeathTrigger");
    }
}
