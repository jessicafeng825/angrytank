﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Animator))]
public class PlayerStateListener : MonoBehaviour
{
    //公有属性
    public float playerWalkSpeed = 3f;              //表示精灵移动的速度
    public GameObject playerRespawnPoint = null;    //表示重生的点
    public float playerJumpForceVertical = 300f;    //表示跳跃时，垂直方向上，力的大小
    public float playerJumpForceHorizontal = 200f;  //表示跳跃时，水平方向上，力的大小
    public float speed = 1;
    public GameObject bulletPrefab = null;          //表示子弹对象
    public Transform bulletSpawnTransform;          //表示创建子弹的位置
                                                    //私有属性
    private Animator playerAnimator = null;         //表示对象上的Animator组件
    private PlayerStateController.playerStates currentState = PlayerStateController.playerStates.idle;  //表示精灵当前的动画状态
    private bool playerHasLanded = true;            //表示精灵是否落地
                                                    //对象可用时，加入到订阅者列表中
    void OnEnable()
    {
        PlayerStateController.onStateChange += onStateChange;
    }
    //不可用时，从订阅者列表中退出
    void OnDisable()
    {
        PlayerStateController.onStateChange -= onStateChange;
    }
    void Start()
    {
        //建立与对象上Animator组件的联系
        playerAnimator = GetComponent<Animator>();
    }
    void LateUpdate()
    {
        onStateCycle();
    }
    //用于检测当前所处的动画状态，在不同的状态下将表现出不同的行为
    void onStateCycle()
    {
        //表示当前对象的大小
        Vector3 localScale = transform.localScale;
        //判断当前处于何种状态
        switch (currentState)
        {
            //向左移动
            case PlayerStateController.playerStates.left:
                transform.Translate(new Vector3((playerWalkSpeed * -1.0f) * Time.deltaTime, 0.0f, 0.0f));
                //角色将转向
                if (localScale.x > 0.0f)
                {
                    localScale.x *= -1.0f;
                    transform.localScale = localScale;
                }
                break;
            //向右移动 
            case PlayerStateController.playerStates.right:
                transform.Translate(new Vector3(playerWalkSpeed * Time.deltaTime, 0.0f, 0.0f));
                //角色将转向
                if (localScale.x < 0.0f)
                {
                    localScale.x *= -1.0f;
                    transform.localScale = localScale;
                }
                break;
            //若处于死亡状态，则需立即进入重生状态
            case PlayerStateController.playerStates.kill:
                onStateChange(PlayerStateController.playerStates.resurrect);
                break;
            //若处于重生状态，则需立即进入idle状态
            case PlayerStateController.playerStates.resurrect:
                onStateChange(PlayerStateController.playerStates.idle);
                break;
           
        }
    }
    //当角色的状态发生改变的时候，调用此函数
    public void onStateChange(PlayerStateController.playerStates newState)
    {
        //如果状态没有发生变化，则无需改变状态
        if (newState == currentState)
            return;
        //判断精灵能否由当前的动画状态，直接转换为另一个动画状态
        if (!checkForValidStatePair(newState))
            return;
        //通过修改Parameter中Walking的值，修改精灵当前的状态
        switch (newState)
        {
            case PlayerStateController.playerStates.idle:
                playerAnimator.SetBool("Walking", false);
                break;
            case PlayerStateController.playerStates.left:
            case PlayerStateController.playerStates.right:
                playerAnimator.SetBool("Walking", true);
                break;
            case PlayerStateController.playerStates.resurrect:
                transform.position = playerRespawnPoint.transform.position;
                break;
            case PlayerStateController.playerStates.jump:
                if (playerHasLanded)
                {
                    //确定精灵的跳跃方向
                    float jumpDirection = 0.0f;
                    if (currentState == PlayerStateController.playerStates.left)
                        jumpDirection = -1.0f;
                    else if (currentState == PlayerStateController.playerStates.right)
                        jumpDirection = 1.0f;
                    else
                        jumpDirection = 0.0f;
                    //给精灵施加一个特定方向的力
                    
                    GetComponent<Rigidbody2D>().AddForce(new Vector2(jumpDirection * playerJumpForceHorizontal, playerJumpForceVertical));
                    playerHasLanded = false;
                }
                break;
            case PlayerStateController.playerStates.landing:
                playerHasLanded = true;
                break;
            case PlayerStateController.playerStates.firingWeapon:
                //实例化一个子弹对象
                GameObject newBullet = (GameObject)Instantiate(bulletPrefab);//实例化一个对象
                //设置子弹的起始位置
                newBullet.transform.position = bulletSpawnTransform.position;
                //建立与子弹对象上PlayerBulletController组件的联系
                PlayerBulletController bullCon = newBullet.GetComponent<PlayerBulletController>();
                //设定子弹对象上的PlayerBulletController组件的player object属性
                bullCon.playerObject = gameObject;
                //发射子弹
                bullCon.launchBullet();
                break;
        }
        //记录角色当前的状态
        currentState = newState;
    }
    //用于确认当前的动画状态能否直接转换为另一动画状态的函数
    bool checkForValidStatePair(PlayerStateController.playerStates newState)
    {
        bool returnVal = false;
        //比较两种动画状态
        switch (currentState)
        {
            case PlayerStateController.playerStates.idle:
            case PlayerStateController.playerStates.left:
            case PlayerStateController.playerStates.right:
            case PlayerStateController.playerStates.firingWeapon:
                returnVal = true;
                break;
            case PlayerStateController.playerStates.kill:
                if (newState == PlayerStateController.playerStates.resurrect)
                    returnVal = true;
                else
                    returnVal = false;
                break;
            case PlayerStateController.playerStates.resurrect:
                if (newState == PlayerStateController.playerStates.idle)
                    returnVal = true;
                else
                    returnVal = false;
                break;
            case PlayerStateController.playerStates.jump:
                if (newState == PlayerStateController.playerStates.landing
                   || newState == PlayerStateController.playerStates.kill
                   || newState == PlayerStateController.playerStates.firingWeapon
                   )
                    returnVal = true;
                else
                    returnVal = false;
                break;
            case PlayerStateController.playerStates.landing:
                if (newState == PlayerStateController.playerStates.left
                   || newState == PlayerStateController.playerStates.right
                   || newState == PlayerStateController.playerStates.idle
                   || newState == PlayerStateController.playerStates.firingWeapon
                   )
                    returnVal = true;
                else
                    returnVal = false;
                break;
            case PlayerStateController.playerStates.falling:
                if (
                    newState == PlayerStateController.playerStates.landing
                    || newState == PlayerStateController.playerStates.kill
                    || newState == PlayerStateController.playerStates.firingWeapon
                    )
                    returnVal = true;
                else
                    returnVal = false;
                break;
        }
        return returnVal;
    }
    public void hitDeathTrigger()
    {
        onStateChange(PlayerStateController.playerStates.kill);
    }
}
