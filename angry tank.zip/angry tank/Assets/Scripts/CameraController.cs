﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    //公有属性
    //表示精灵当前的动画状态
    public PlayerStateController.playerStates currentPlayerState = PlayerStateController.playerStates.idle;
    public GameObject playerObject = null;                  //表示精灵对象
    public float cameraTrackingSpeed = 1f;                  //表示摄像机的追踪速度
                                                            //私有属性
    private Vector3 lastTargetPosition = Vector3.zero;      //上一目标位置
    private Vector3 currTargetPosition = Vector3.zero;      //下一目标位置
    private float currLerpDistance = 0.0f;
    //方法
    void Start()
    {
        Vector3 playerPos = playerObject.transform.position;        //记录精灵的位置
        Vector3 startTargPos = playerPos;
        lastTargetPosition = startTargPos;
        currTargetPosition = startTargPos;
    }
    //加入订阅者列表
    void OnEnable()
    {
        PlayerStateController.onStateChange += onPlayerStateChange;
    }
    //从订阅者列表中退出
    void OnDisable()
    {
        PlayerStateController.onStateChange -= onPlayerStateChange;
    }
    //实时记录游戏精灵当前的动画状态
    void onPlayerStateChange(PlayerStateController.playerStates newState)
    {
        currentPlayerState = newState;
    }
    void LateUpdate()
    {
        //依据当前精灵的动画状态，实时更新
        onStateCycle();
        //将摄像头移动到目标位置
        currLerpDistance += cameraTrackingSpeed;
        transform.position = Vector3.Lerp(lastTargetPosition, currTargetPosition, currLerpDistance);
    }
    void onStateCycle()
    {
        switch (currentPlayerState)
        {
            default:
                trackPlayer();
                break;
        }
    }
    void trackPlayer()
    {
        //获取并保存摄像机和精灵在世界坐标系的坐标
        Vector3 currCamPos = transform.position;
        Vector3 currPlayerPos = playerObject.transform.position;
        lastTargetPosition = currCamPos;
        currTargetPosition = currPlayerPos;
        currTargetPosition.z = currCamPos.z;            //保证摄像头z轴方向上的值不变
    }
}
