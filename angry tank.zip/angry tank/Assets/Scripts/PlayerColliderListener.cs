﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerColliderListener : MonoBehaviour
{
    public PlayerStateListener targetStateListener = null;          //表示精灵对象
                                                                    //进入碰撞检测区域时，调用此函数
    void OnTriggerEnter2D(Collider2D collidedObject)
    {
        switch (collidedObject.tag)
        {
            //当精灵落到地面上时，触发landing动画状态
            case "Platform":
                targetStateListener.onStateChange(PlayerStateController.playerStates.idle);
                break;
        }
    }
    //离开碰撞检测区域时，调用此函数
    void OnTriggerExit2D(Collider2D collidedObject)
    {
        switch (collidedObject.tag)
        {
            //当精灵离开地面是，触发falling动画状态
            case "Platform":
                targetStateListener.onStateChange(PlayerStateController.playerStates.falling);
                break;
            //当精灵离开的是Death Trigger对象，则触发kill动画状态
            case "DeathTrigger":
                targetStateListener.onStateChange(PlayerStateController.playerStates.kill);
                break;
        }
    }
}
