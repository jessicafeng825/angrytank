﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStateController : MonoBehaviour
{
    //定义游戏人物的各种状态
    public enum playerStates
    {
        idle = 0,                       //表示空闲
        left,                           //表示左移
        right,                          //表示右移
        kill,                           //表示死亡
        resurrect,                      //表示重生
        jump,                           //表示跳跃
        landing,                        //表示落地
        falling,                        //表示降落过程
        firingWeapon                    //表示开火
    }
    //定义委托和事件	
    public delegate void playerStateHandler(PlayerStateController.playerStates newState);
    public static event playerStateHandler onStateChange;
    void LateUpdate()
    {
        //获取玩家在键盘上对A、D，或者左、右方向键的输入
        float horizontal = Input.GetAxis("Horizontal");
        if (horizontal != 0.0f)
        {
            //如果按下的是左方向键，则广播左移状态
            if (horizontal < 0.0f)
            {
                if (onStateChange != null)
                    onStateChange(PlayerStateController.playerStates.left);
            }
            //如果按下的是右方向键，则广播右移状态
            else
            {
                if (onStateChange != null)
                    onStateChange(PlayerStateController.playerStates.right);
            }
        }
        else
        {
            //广播空闲状态
            if (onStateChange != null)
                onStateChange(PlayerStateController.playerStates.idle);
        }
        //当玩家按下键盘上的空格键时，进入跳跃状态
        float jump = Input.GetAxis("Jump");
        if (jump > 0.0f)
        {
            if (onStateChange != null)
                onStateChange(PlayerStateController.playerStates.jump);
        }
        //当玩家按下鼠标的左键时，进入开火状态
        float firing = Input.GetAxis("Fire1");
        if (firing > 0.0f)
        {
            if (onStateChange != null)
                onStateChange(PlayerStateController.playerStates.firingWeapon);
        }
    }
}
